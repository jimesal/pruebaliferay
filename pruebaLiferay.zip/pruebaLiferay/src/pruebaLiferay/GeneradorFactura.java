package pruebaLiferay;

import java.io.* ;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class GeneradorFactura {
	
	private Scanner reader ;
	private FileWriter writer ;
	
	private ArrayList<ProductoLista> lista ;
	private ArrayList<String> exentos ;
	
	private double totalTax ;
	private double total ;
	
	public GeneradorFactura(File input, File output, File exencion) {
		
		reader = null ;
		writer = null ; 
		lista = new ArrayList<ProductoLista>() ;
		exentos = new ArrayList<String>() ;
		totalTax = 0 ;
		total = 0 ;
		
		try {
			reader = new Scanner(new FileReader(exencion, Charset.forName("iso-8859-1")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String linea = leerLinea() ;
		while(linea != null) {
			exentos.add(linea) ;
			linea = leerLinea() ;
		}
		
		try {
			reader = new Scanner(new FileReader(input, Charset.forName("iso-8859-1")));
			writer = new FileWriter(output, Charset.forName("iso-8859-1")) ;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public void producir() {
		this.lectura() ;
		this.calculo() ;
		this.escritura() ;
	}
	
	private void lectura() {
		String linea = leerLinea() ;
		while(linea != null) {
			//Contengo en elementos separados de la lista cada "palabra" de la linea
			List<String> arr = Arrays.asList(linea.trim().split(" ")) ;
			
			String precio = arr.get(arr.size()-2).replace(',', '.') ;
			
			String name = "" ;
			int index = 1 ;
			while(index < arr.size()-4) {
				name = name + arr.get(index) + " " ;
				index++ ;
			}
			//no incluir " " despu�s de la �ltima palabra
			name = name + arr.get(index) ;
			
			boolean importado = name.contains("import") ;
				
			ProductoLista producto = new ProductoLista(Integer.parseInt(arr.get(0)),name,Double.parseDouble(precio), importado) ;
			lista.add(producto) ;
			
			linea = leerLinea() ;
		}
	}
	
	private void calculo() {
		for (ProductoLista p : lista) {
			double taxImp =  p.isImp() ? p.getPrice() * 0.05 : 0 ;
			double taxVent = calculoTaxVent(p) ;
			//Redondeo ambos impuestos con dos d�gitos de precisi�n hacia arriba en m�ltiplos de 5
			double sumTax= 5*(Math.ceil(Math.abs((taxImp + taxVent)*100d/5)))/100d;
			//Redondeo con dos digitos de precisi�n
			p.setPrice((Math.round((p.getPrice() + sumTax)*100d)/100d));
			totalTax = totalTax + p.getNum()*sumTax ;
			total = total + p.getNum()*p.getPrice() ;
		}
		
		//Redondeo con dos d�gitos de precisi�n
		totalTax = Math.round(totalTax*100d)/100d;
		total = Math.round(total*100d)/100d;
	}
	
	//En caso de que el producto sea importado, hago la comparativa con los productos exentos sin considerar la palabra "importado"
	private double calculoTaxVent(ProductoLista p) {
		String newName = p.getName();
		if(p.isImp()) {
			newName = String.copyValueOf(p.getName().toCharArray(), 0, p.getName().lastIndexOf(" ")) ;
		}
		return exentos.contains(newName) ? 0 : p.getPrice() * 0.1  ;
	}
	
	private void escritura() {
		try {
			for (ProductoLista p : lista) {
					writer.write(p.toString() + "\n");
				}
			
			if(totalTax > 0)
				writer.write("Impuestos sobre las ventas: " + String.valueOf(this.totalTax) + " EUR\n" ) ;
			writer.write("Total: " + String.valueOf(this.total) + " EUR" ) ;
	
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private String leerLinea() {
		String linea = null ;
		if (reader.hasNextLine())
			linea = reader.nextLine();
		return linea ;
			
			
	}

}
