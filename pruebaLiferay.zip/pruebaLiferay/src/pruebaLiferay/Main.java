package pruebaLiferay;

import java.io.File;

public class Main {
	public static void main(String[] args) {

	File input = new File(System.getProperty("user.dir") + "/entradas/entrada4");
	File output = new File(System.getProperty("user.dir") + "/salidas/salida1");
	
	//productos exentos del impuesto base
	File exencion = new File(System.getProperty("user.dir") + "/entradas/exencion");
	
	GeneradorFactura GF = new GeneradorFactura(input, output, exencion) ;
	
	GF.producir() ;
	
	}		
}
