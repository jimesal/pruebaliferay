package pruebaLiferay;

public class ProductoLista {
	
	private int num ;
	private String name ;
	private double price ;
	private boolean isImp ;
	
	public ProductoLista(int num, String name, double price, boolean isImp) {
		super();
		this.num = num;
		this.name = name;
		this.price = price;
		this.isImp = isImp;
	}
	
	public int getNum() {
		return num;
	}
	
	public String getName() {
		return name;
	}
	
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isImp() {
		return isImp;
	}

	@Override
	public String toString() {
		return String.valueOf(num) + " " + name + ": " + String.valueOf(price) + " EUR" ;
	}




	
}
